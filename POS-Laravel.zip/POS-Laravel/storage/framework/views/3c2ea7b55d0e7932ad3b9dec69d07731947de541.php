<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      Developed By Ang Kosal
    </div>
    <strong>&copy; <?php echo date('Y')?> - Point of Sale System</strong> - PHP Laravel
  </footer><?php /**PATH F:\codeastro\Laravel\02 TEST PROJ\POS-Laravel\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>