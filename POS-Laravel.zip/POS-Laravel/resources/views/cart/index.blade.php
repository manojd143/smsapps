@extends('layouts.admin')

@section('title', 'Open POS')

@section('content')
    <div id="cart"></div>

@endsection
