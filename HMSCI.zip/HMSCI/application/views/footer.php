    <div style="clear:both;color:#aaa; padding:20px;">

    	<hr /><center>&copy; <?php echo date ('Y'); ?> Hospital Management System - Developed by John Sokpo</center>

    </div>