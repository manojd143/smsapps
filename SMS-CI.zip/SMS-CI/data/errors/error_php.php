    
    
<code >
       

<h4>SMS Debug ===> Error Encountered!</h4>             
                                              
<p>Severity: <?php echo $severity; ?></p>  
<p>Message:  <?php echo $message; ?></p>   
<p>Filename: <?php echo $filepath; ?></p>  
<p>Line Number: <?php echo $line; ?></p>   
--------------------------------------------   
    </code>
 
