<script type="text/javascript" src="<?php echo base_url()?>assets/dist/js/angular.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>assets/ng/app.js"></script>
<!-- <script type="text/javascript" src="<?php //echo base_url()?>assets/dist/js/list.js"></script> -->


