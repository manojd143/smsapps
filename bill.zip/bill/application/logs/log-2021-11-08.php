<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-08 21:21:45 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\XAMPP\htdocs\bill\system\database\DB_driver.php 38
