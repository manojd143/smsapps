<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-22 17:46:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 D:\XAMPP\htdocs\bill\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-01-22 17:46:45 --> Unable to connect to the database
ERROR - 2022-01-22 18:04:14 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ';' or '{' D:\XAMPP\htdocs\bill\vendor\phpoffice\phpspreadsheet\src\PhpSpreadsheet\IOFactory.php 194
ERROR - 2022-01-22 18:04:31 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ';' or '{' D:\XAMPP\htdocs\bill\vendor\phpoffice\phpspreadsheet\src\PhpSpreadsheet\IOFactory.php 194
ERROR - 2022-01-22 18:05:07 --> Severity: Warning --> require(D:\XAMPP\htdocs\bill\application\third_party/PHPExcel/Autoloader.php): failed to open stream: No such file or directory D:\XAMPP\htdocs\bill\application\third_party\PHPExcel.php 32
ERROR - 2022-01-22 18:05:07 --> Severity: Compile Error --> require(): Failed opening required 'D:\XAMPP\htdocs\bill\application\third_party/PHPExcel/Autoloader.php' (include_path='.;D:\XAMPP\php\PEAR') D:\XAMPP\htdocs\bill\application\third_party\PHPExcel.php 32
ERROR - 2022-01-22 18:10:17 --> Severity: Warning --> require(D:\XAMPP\htdocs\bill\application\third_party/PHPExcel/Autoloader.php): failed to open stream: No such file or directory D:\XAMPP\htdocs\bill\application\third_party\PHPExcel.php 32
ERROR - 2022-01-22 18:10:17 --> Severity: Compile Error --> require(): Failed opening required 'D:\XAMPP\htdocs\bill\application\third_party/PHPExcel/Autoloader.php' (include_path='.;D:\XAMPP\php\PEAR') D:\XAMPP\htdocs\bill\application\third_party\PHPExcel.php 32
ERROR - 2022-01-22 18:15:58 --> Severity: Warning --> require(D:\XAMPP\htdocs\bill\application\third_party/PHPExcel/Autoloader.php): failed to open stream: No such file or directory D:\XAMPP\htdocs\bill\application\third_party\PHPExcel.php 32
ERROR - 2022-01-22 18:15:58 --> Severity: Compile Error --> require(): Failed opening required 'D:\XAMPP\htdocs\bill\application\third_party/PHPExcel/Autoloader.php' (include_path='.;D:\XAMPP\php\PEAR') D:\XAMPP\htdocs\bill\application\third_party\PHPExcel.php 32
ERROR - 2022-01-22 18:18:31 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ';' or '{' D:\XAMPP\htdocs\bill\vendor\phpoffice\phpspreadsheet\src\PhpSpreadsheet\IOFactory.php 194
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\ZipStreamWrapper.php 78
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\String.php 520
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\String.php 521
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\String.php 527
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\String.php 527
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\String.php 528
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\String.php 528
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2103
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2103
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2211
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2211
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2213
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2266
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2268
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2548
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2674
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2676
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2677
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2952
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2952
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2955
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 2956
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 3359
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 3359
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 3394
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 3398
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 3451
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation.php 3452
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\ReferenceHelper.php 601
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\ReferenceHelper.php 601
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\ReferenceHelper.php 604
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\ReferenceHelper.php 604
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1616
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1674
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1811
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1833
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1843
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1861
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1874
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1878
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 1960
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2083
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2083
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2083
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2099
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2099
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2099
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2115
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2115
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2115
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2131
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2131
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2131
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2147
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2147
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2147
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2163
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2163
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2163
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2179
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2179
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2179
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2195
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2195
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2195
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2236
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2300
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2308
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2483
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2565
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2634
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 2658
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3531
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3555
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3556
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3557
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3571
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3572
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3573
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3577
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3579
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3580
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3581
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3585
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3587
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3588
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3589
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3656
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3721
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 3724
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 4023
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 4171
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 4173
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 5704
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 5707
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 6105
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 6108
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Reader\Excel5.php 6111
ERROR - 2022-01-22 18:19:48 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\OLE.php 290
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Shared\OLE.php 450
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 680
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 681
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 683
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 684
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 684
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 685
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 686
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 686
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 686
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell.php 689
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2022-01-22 18:19:48 --> Severity: Notice --> Trying to access array offset on value of type int D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Writer\Excel5\Parser.php 1024
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Writer\Excel5\Parser.php 1046
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Writer\Excel5\Parser.php 1051
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Writer\Excel5\Parser.php 1057
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Writer\Excel5\Parser.php 1059
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Writer\Excel5\Parser.php 1074
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Writer\Excel5\Parser.php 1202
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Writer\Excel5\Parser.php 1202
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation\Functions.php 311
ERROR - 2022-01-22 18:19:48 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation\Functions.php 523
ERROR - 2022-01-22 18:19:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\XAMPP\htdocs\bill\system\core\Exceptions.php:271) D:\XAMPP\htdocs\bill\system\core\Common.php 578
ERROR - 2022-01-22 18:19:48 --> Severity: Compile Error --> 'break' not in the 'loop' or 'switch' context D:\XAMPP\htdocs\bill\application\third_party\PHPExcel\Calculation\Functions.php 570
