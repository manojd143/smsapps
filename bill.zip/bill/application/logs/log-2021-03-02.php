<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-02 17:45:39 --> Query error: Table 'ke.organisation' doesn't exist - Invalid query: SELECT `organisation`.*
FROM `organisation`
ERROR - 2021-03-02 17:45:43 --> Query error: Table 'ke.organisation' doesn't exist - Invalid query: SELECT `organisation`.*
FROM `organisation`
