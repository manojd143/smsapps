<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-02-15 16:30:19 --> Severity: Notice --> Undefined property: ItemGroups_Controller::$form_validation C:\xampp\htdocs\bill\application\controllers\ItemGroups_Controller.php 58
ERROR - 2021-02-15 16:30:19 --> Severity: error --> Exception: Call to a member function set_rules() on null C:\xampp\htdocs\bill\application\controllers\ItemGroups_Controller.php 58
ERROR - 2021-02-15 16:47:50 --> Severity: Notice --> Undefined variable: attributes C:\xampp\htdocs\bill\application\views\ItemGroups_view.php 229
