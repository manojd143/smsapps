<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-02 22:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'ke' D:\XAMPP\htdocs\bill\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-06-02 22:23:02 --> Unable to connect to the database
ERROR - 2021-06-02 22:23:10 --> Query error: Table 'ke.organisation' doesn't exist - Invalid query: SELECT `organisation`.*
FROM `organisation`
ERROR - 2021-06-02 22:28:18 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Quotation_Controller.php 112
ERROR - 2021-06-02 22:28:18 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Quotation_Controller.php 113
ERROR - 2021-06-02 22:28:18 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Quotation_Controller.php 114
ERROR - 2021-06-02 22:28:18 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Quotation_Controller.php 115
ERROR - 2021-06-02 22:28:18 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Quotation_Controller.php 116
ERROR - 2021-06-02 22:43:19 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 111
ERROR - 2021-06-02 22:43:19 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 112
ERROR - 2021-06-02 22:43:19 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 113
ERROR - 2021-06-02 22:43:19 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 114
ERROR - 2021-06-02 22:43:19 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 115
ERROR - 2021-06-02 22:45:26 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 111
ERROR - 2021-06-02 22:45:26 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 112
ERROR - 2021-06-02 22:45:26 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 113
ERROR - 2021-06-02 22:45:26 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 114
ERROR - 2021-06-02 22:45:26 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 115
ERROR - 2021-06-02 22:45:42 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 111
ERROR - 2021-06-02 22:45:42 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 112
ERROR - 2021-06-02 22:45:42 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 113
ERROR - 2021-06-02 22:45:42 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 114
ERROR - 2021-06-02 22:45:42 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 115
ERROR - 2021-06-02 22:46:23 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 111
ERROR - 2021-06-02 22:46:23 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 112
ERROR - 2021-06-02 22:46:23 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 113
ERROR - 2021-06-02 22:46:23 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 114
ERROR - 2021-06-02 22:46:23 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 115
ERROR - 2021-06-02 22:46:50 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 111
ERROR - 2021-06-02 22:46:50 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 112
ERROR - 2021-06-02 22:46:50 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 113
ERROR - 2021-06-02 22:46:50 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 114
ERROR - 2021-06-02 22:46:50 --> Severity: Notice --> Undefined offset: 0 D:\XAMPP\htdocs\bill\application\controllers\Sale_Controller.php 115
