<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Billing System</title>
	<script type="text/javascript" src="<?php echo base_url(); ?>bootstrap/js/jquery.js"></script>
	<link rel='stylesheet' href='<?php  echo base_url();  ?>bootstrap/css/bootstrap.css'>
	<link href="<?php echo base_url(); ?>bootstrap/images/diamond.png" rel="shortcut icon" type="image/x-icon" />
</head>
<body>
