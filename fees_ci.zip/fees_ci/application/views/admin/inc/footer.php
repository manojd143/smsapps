<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      
    </div>
    <!-- Default to the left -->
    <strong><?php echo date("Y"); ?> - Fees Management System PHP CodeIgniter</strong>
  </footer>